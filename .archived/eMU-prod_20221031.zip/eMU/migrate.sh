#!/usr/bin/env bash
# PURPOSE: Transfer DICOM objects from one system to another.
# AUTHOR: Joel Booth
# DATE: Sept 2022

if [[ "$(whoami)" != "medsrv" ]]; then echo "Script must be run as user: medsrv, exiting"; exit 1; fi
source cfg/.default.cfg || { echo "Failed to source cfg/.default.cfg, exiting"; exit 1; }
source cfg/migrate.cfg || { echo "Failed to source cfg/migrate.cfg, exiting"; exit 1; }
source "${HOME}/var/conf/setenv.sh" || { echo "Failed to source ${HOME}/var/conf/setenv.sh, exiting"; exit 1; }
source "${HOME}/var/dicom/pb-scp.cfg" || { echo "Failed to source ${HOME}/var/dicom/pb-scp.cfg, exiting"; exit 1; }
source lib/common.lib || { echo "Failed to source lib/common.lib, exiting"; exit 1; }
source lib/medsrv.lib || { echo "Failed to source lib/medsrv.lib, exiting"; exit 1; }
source lib/migrate.lib || { echo "Failed to source lib/migrate.lib, exiting"; exit 1; }
Gate_BASH_Version # Do not allow further execution if BASH version requirement is not met

main() {
  # PARSE OPTIONS
  while :; do
    case $1 in
      # TROUBLESHOOTING
          zero_args_given) usage_mini; break;;
        --debug|-d) _Debugging="1";; 
        --verbose|-v) _Verbose=$((_Verbose + 1));;
      # PRE-MIGRATION
        --initialize|-I) 
            Install_Migration_Database;; #Tested 7/26/2022 - Success
        --add-system) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            addSystemInteractive;; #Tested 7/26/2022 - Success
        --make-study-list) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            makeStudyList_interactive;; #Tested 7/26/2022 - Success
        --load-extract|-L) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            load_MigDB_with_extract "$2";;
      # DURING MIGRATION
        --clear-stuck-locks) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            clear_stuck_locks;; #Tested 7/26/2022 - Success
        --now|-N) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            chk_landscape
            whats_migrating_right_now;; #Tested 7/26/2022 - Success
        --next|-Q) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            chk_landscape
            next_N_queued_exams "$2";; #Tested 7/26/2022 - Success
        --latest-xfers) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            chk_landscape
            last_N_processed_exams "$2";; #Tested 7/26/2022 - Success
        --migrate|-M) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            chk_landscape
            migration.start "$2";;
        --SLV) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            SLV_Menu;;
        --summary|-S) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            printSummary;;
        --report|-R) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Prompt_IfMigrationSystems_DoNotExist
            migrated_exams_export;;
      # ADMINISTRATIVE
        --show-systems) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            #Prompt_IfMigrationSystems_DoNotExist
            show_systems;;
        --splits-merges-deletes) 
            identify_splits_merges_and_deletes;;
        --backup) 
            Exit_IfMigration_IsNot_Installed "${_MIGRATION_DATABASE}" "$_VIEW_ALLSTYINFO"
            Execute_Backup_Handler "$2";;
        -h) usage_mini; break;;
        --help) usage; break;;
        --) shift; break;; # End of all options
        -?*) Stream_Handler -L no -T WARN  "Unknown option (ignored): $1";;
        *) break;;
    esac
    shift
  done
}

Create_Directories_If_NoT_Exists "${_REQUIRED_DIRECTORIES[@]}"
Periodic_Database_Backup
Remove_Write_Permission "${PWD}"/"${_CFGS_DIR}"/.default.cfg
main "${@:-zero_args_given}"
