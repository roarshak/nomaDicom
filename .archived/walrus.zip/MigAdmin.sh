#!/bin/bash
#shellcheck disable=SC1090,SC1091
# NOTE: This script (MigAdmin.sh) and MigTransfer.sh designed to leverage
#       the universal.lib function library.
#       The self-contained DCM Transfer scripts should not depend at all
#       on the universal.lib function library.
# TODO: Synchronize logging strategy
# TODO: Find a good way to get more study info for inserted exams
# TODO: what about installing when case_##### db already exists?
# TODO: Change this rejection output:
# [medsrv@Migration-Team-PACS-Hub1-v8 20240422]$ ./MigAdmin.sh -a study-list_20240430-102954.tsv
# All required variables are set and have non-empty values.
# 20240430-103011 System label DefaultSystem20240430 not found. Exiting.
# TODO: It is asking for case number even though it was already defined.
# [medsrv@xray case_70731]$ ./MigAdmin.sh --install
# All required variables are set and have non-empty values.
# Please enter a five-digit case number:


Usage() {
    # local topic="${1,,}"  # Bash 4.0+ required
    local topic="$(echo "$1" | tr '[:upper:]' '[:lower:]')"

    local setup_config_info="Options for Setup & Config:
      --install
          Perform a fresh installation.
          Example: $0 --install

      --insert-system <system_label>
          Insert a system record.
          Example: $0 --insert-system 'old_v7_prod'

      --edit-system
          Edit an existing system record. Displays a list of systems for selection.

      -a, --all <file_path> [<system_label> [<database_name>]]
          Import study records from a CSV file containing multiple columns.
          Example: $0 --all 'file_path' 'old_v7_prod'
          CSV File format: Each line should contain STYIUID, number of objects, and the cumulative size of objects.
          Example CSV content: 1.2.840.142.4.11373.113797.122574.721925 250 1250000
                               1.2.840.142.4.11373.113798.122575.721926 300 1500000
                               1.2.840.142.4.11373.113799.122576.721927 100 500000
          To generate a multi-column file with viable study instance UIDs, number of objects, and sum size for migration:
          Example: sql.sh \"SELECT styiuid, numofobj, sumsize FROM Dcstudy WHERE mainst>='0' AND Dcstudy_d!='yes' AND derived NOT IN('copy','shortcut')\" -N > study-list_\$(date \"+%Y%m%d-%H%M%S\").tsv
          If you have SSH connectivity, you can fetch the remote study list with multiple columns using this command:
          Example: ssh remote_pacs \"sql.sh \\\"SELECT styiuid, numofobj, sumsize FROM Dcstudy WHERE mainst>='0' AND Dcstudy_d!='yes' AND derived NOT IN('copy','shortcut')\\\" -N\" >study-list_\$(date \"+%Y%m%d-%H%M%S\")_remote.tsv

      -s, --single <file_path> [<system_label> [<database_name>]]
          Import STYIUIDs from a single-column CSV file.
          Example: $0 --single 'file_path' 'old_v7_prod'
          Single-column CSV File format: Each line should contain a single STYIUID.
          Example CSV content: 1.2.840.142.4.11373.113797.122574.721925
                                 1.2.840.142.4.11373.113798.122575.721926
                                 1.2.840.142.4.11373.113799.122576.721927
          To generate a single-column file with viable study instance UIDs for migration:
          Example: sql.sh \"SELECT styiuid FROM Dcstudy WHERE mainst>='0' AND Dcstudy_d!='yes' AND derived NOT IN('copy','shortcut')\" -N > suid-list_\$(date \"+%Y%m%d-%H%M%S\").txt
          If you have SSH connectivity, you can fetch the remote study list using this command:
          Example: ssh remote_pacs \"sql.sh \\\"SELECT styiuid FROM Dcstudy WHERE mainst>='0' AND Dcstudy_d!='yes' AND derived NOT IN('copy','shortcut')\\\" -N\" >suid-list_\$(date \"+%Y%m%d-%H%M%S\")_remote.txt
          "

    local study_adjustments_info="Options for Study Adjustments:
      -I|-i <styiuid>
      --study-info <styiuid>
          Gather exam state information.
          Example: $0 -S '1.2.840.142.4.11373.113797.122574.721925'

      --insert-study <styiuid> [database name]
          Insert a study record.
          Example: $0 --insert-study '1.2.840.142.4.11373.113797.122574.721925'

      --set-failed <styiuid> [database name]
          Set verification status to 'failed' for a specific study, requires comment.

      -l, --link <styiuid> <system_label> [database name]
          Link a study and system.

      --insert-link <styiuid> <system_label> [database name]
          Insert and link a study with a system."

    local queries_info="Options for Queries:
      -Q, --query-context
          Display project context information.
          Example: $0 -Q"

    case "$topic" in
        *setup*|*config*)
            echo "$setup_config_info"
            ;;
        *study*|*adjustment*)
            echo "$study_adjustments_info"
            ;;
        *query*|*queries*)
            echo "$queries_info"
            ;;
        *)
            echo "Usage: $0 --help [topic]"
            echo "Topics available:"
            echo "  Setup & Config      Configure system settings and perform installations."
            echo "  Study Adjustments   Modify and manage study records."
            echo "  Queries             Display system and project context information."
            ;;
    esac
}
initialize_environment() {
    BatchMode="${BatchMode:-true}"
    if ! . universal.lib; then
        echo "Required library (universal.lib) not found. Exiting..."; exit 1
    else
        initialize_script_variables "MigAdmin.sh"  # Sets: _SCRIPT_NAME, _SCRIPT_CFG, _SCRIPT_LOG
        initialize_script_environment              # Verifies $USER, Verifies/Sources .default.cfg & migration.cfg
        verify_env || exit 1                       # Ensure all ${env_vars[@]} are set & not empty.
    fi
}
main() {
    initialize_environment

    if [ "$#" -eq 0 ]; then
        Usage
        exit 0
    fi

    while [[ "$#" -gt 0 ]]; do
        case "$1" in
            -h|--help) Usage "$2"; exit 0 ;;
            --install) FreshInstall; exit 0 ;;
            -Q|--query-context) QueryFor_ "$MigDB"; exit 0 ;;
            -u) refresh_verification "$MigDB"; set_skip_for_target_only_exams "$MigDB"; exit 0 ;;
            --insert-study) InsertStudy "$2" "$MigDB"; shift 2 ;;
            -i|-I|--study-info) getStudyInfo "$2"; shift 1 ;;
            -f|--set-failed) set_failed_with_comment_check "$2" "${3:-$MigDB}"; shift 2 ;;
            -z) load_system_details ;;
            -t|--insert-system) upsert_system_from_file "$(pwd)/$2" "$MigDB"; shift 2 ;;
            -e|--edit-system) choose_system; exit 0 ;;
            -l|--link) LinkStudySystem "$2" "$3" "${4:-$MigDB}"; shift 3 ;;
            -a|--all) ImportMultiColStyListViaCSV "$2" "$3" "${4:-$MigDB}"; shift 3 ;;
            --fetch-all) FetchStudyList "$2"; shift 1 ;;
            -s|--single) ImportStyListViaCSV "$2" "$3" "${4:-$MigDB}"; shift 3 ;;
            --insert-link) InsertAndLinkRecords "$2" "$3" "${4:-$MigDB}"; shift 3 ;;
            *) echo "Unknown option: $1" >&2; Usage; exit 1 ;;
        esac
        shift
    done
}

main "$@"
