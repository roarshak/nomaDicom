#!/bin/bash
#shellcheck disable=SC1090,SC1091
# NOTE: This script (MigAdmin.sh) and MigTransfer.sh designed to leverage
#       the universal.lib function library.
#       The self-contained DCM Transfer scripts should not depend at all
#       on the universal.lib function library.
# TODO Fix verbose option behavior
# TODO Synchronize logging strategy
# TODO Implement Multiple_PbR_Check() into existing functionality

main_OG() {
    initialize_environment

    getOptions "$@"
    trap 'interrupted=1' SIGINT

    export BatchMode #Not used in this script, but leveraged by helper scripts.
    # export SUID Target_AET Source_AET Source_IP Source_Port _DEBUG_OPTS _VERBOSE_OPTS AE_TITLE
    export SUID _DEBUG_OPTS _VERBOSE_OPTS
    while read -r SUID; do
      interrupt_check || break
      source_file_if_checksum_has_changed "$MigrationConfigFile"
      if skip_if_processed "$SUID"; then
        printf "%s skipping %s, already processed\n" "$(date "+$_DATE_FMT")" "$SUID"
        continue
      fi

      if [[ "${_DRY_RUN:="n"}" == "n" ]]; then
          checkTime
          checkLoad
      else
          _date="${_date} DRY_RUN"
      fi
      interrupt_check || break

      # Call a different transfer script based on _METHOD
      _date="$(date "+$_DATE_FMT")"
      if [[ "${_METHOD:="move"}" == "move" ]]; then
        # printf "%s movescu %s FROM:%s TO:%s\n" "$_date" "${SUID}" "$Source_Label" "$Target_Label" | tee -a "$_SCRIPT_LOG"
        printf "./moveExam.sh -S %s --target-ae %s --source-ae %s --source-ip %s --source-port %s %s %s\n" "$SUID" "$Target_AET" "$Source_AET" "$Source_IP" "$Source_Port" "$_DEBUG_OPTS" "$_VERBOSE_OPTS" | tee -a "$_LOG_MIGRATION"
        [[ "${_DRY_RUN:="n"}" == "n" ]] && \
          ./moveExam.sh -S "$SUID" \
            --target-ae "$Target_AET" \
            --source-ae "$Source_AET" \
            --source-ip "$Source_IP" \
            --source-port "$Source_Port" "$_DEBUG_OPTS" "$_VERBOSE_OPTS"
          _rc_movescu=$?
          if [[ $_rc_movescu -ne 0 ]]; then
            printf "%s movescu %s FROM:%s TO:%s failed with exit code %s\n" "$_date" "${SUID}" "$Source_Label" "$Target_Label" "$_rc_movescu" | tee -a "$_LOG_MIGRATION"
            exit 1
          fi
      elif [[ "${_METHOD:="move"}" == "runjavacmd" ]]; then
        echo "Under construction, exiting."
        exit 1
        # All the Target_* & Source_* variables were removed from migration.cfg
        # and are now defined via dcm-node.<label>.cfg files.
        # Target_DeviceName was the only variable that did not make the cut,
        # therefore it will need to be instantiated another way.
        # ./fwdExam.sh "${_DRY_RUN:-""}" "$_DEBUG_OPTS" "$_VERBOSE_OPTS" -S "$SUID"
      else
        echo "Unknown transfer method: $_METHOD" >&2
        exit 1
      fi

      sleep ${interstitial_sleep:=3}
      interrupt_check || break
    done < "$_INPUT_FILE"

    trap - SIGINT  # Reset trap to default behavior
}
Usage() {
  {
    printf "Usage: %s [OPTION]... [METHOD]... [SUID]...\n" "$(getScriptName)"
    printf "\n"
    printf "  -h, --help\t\tDisplay this help and exit\n"
    printf "  -L, --list\tSpecify the file containing the list of SUIDs to transfer\n"
    printf "  -if, --whatif\t\tDry run, do not actually transfer\n"
    printf "  -v, --verbose\t\tVerbose output\n"
    printf "  -d, --debug\t\tDebug output\n"
    printf "  --script\t\tDo not log results to a file\n"
  } >&2 # Redirects all output of this block to stderr
  exit 0
}
initialize() {
  initialize_environment
  getOptions "$@"
  trap 'interrupted=1' SIGINT
}
initialize_environment() {
    BatchMode="${BatchMode:-true}"
    if ! . universal.lib; then
        echo "Required library (universal.lib) not found. Exiting..."; exit 1
    else
        initialize_script_variables "MigTransfer.sh"  # Sets: _SCRIPT_NAME, _SCRIPT_CFG, _SCRIPT_LOG
        initialize_script_environment                 # Verifies $USER, Verifies/Sources .default.cfg & migration.cfg
        load_system_details                           # Loads Target_* & Source_* variables
        verify_env || exit 1                          # Ensure all ${env_vars[@]} are set & not empty.
    fi
}
process_suid() {
  local SUID="$1"
  
  interrupt_check || return 1
  source_file_if_checksum_has_changed "$MigrationConfigFile"
  
  if skip_if_processed "$SUID"; then
      printf "%s skipping %s, already processed\n" "$(date "+$_DATE_FMT")" "$SUID"
      return 0
  fi
  
  if [[ "${_DRY_RUN:="n"}" == "n" ]]; then
      checkTime
      checkLoad
  else
      _date="${_date} DRY_RUN"
  fi
  
  interrupt_check || return 1
  transfer_suid "$SUID"
  return 0
}
transfer_suid() {
  local SUID="$1"
  _date="$(date "+$_DATE_FMT")"
  
  case "${_METHOD:="move"}" in
      move)
          transfer_move "$SUID"
          ;;
      runjavacmd)
          echo "Under construction, exiting."
          exit 1
          ;;
      *)
          echo "Unknown transfer method: $_METHOD" >&2
          exit 1
          ;;
  esac
  
  sleep ${interstitial_sleep:=3}
}
transfer_move() {
  local SUID="$1"

  printf "./moveExam.sh -S %s --target-ae %s --source-ae %s --source-ip %s --source-port %s %s %s\n" "$SUID" "$Target_AET" "$Source_AET" "$Source_IP" "$Source_Port" "$_DEBUG_OPTS" "$_VERBOSE_OPTS" | tee -a "$_LOG_MIGRATION"

  if [[ "${_DRY_RUN:="n"}" == "n" ]]; then
      verifySelfAET
      verifyTargetDevice
      Assemble_Cmove_Opts
      Move_Study
    
      local _rc_movescu=$?
    
      if [[ $_rc_movescu -ne 0 ]]; then
          printf "%s movescu %s FROM:%s TO:%s failed with exit code %s\n" "$_date" "${SUID}" "$Source_Label" "$Target_Label" "$_rc_movescu" | tee -a "$_LOG_MIGRATION"
          exit 1
      fi
  fi
}
getOptions() {
  executedByUser=True
  [ $# -eq 0 ] && Usage
  while [ -n "$1" ]; do
    case $1 in
      --help|-h) Usage ;;
      --verbose|-v) _VERBOSE_OPTS="--verbose" ;;
      --debug|-d) _DEBUG_OPTS="--debug" ;;
      --script) executedByUser=False ;;
      --list|-L)
        if [ -n "$2" ] && [[ "$2" != -* ]]; then
          _INPUT_FILE="$2"
          shift
        else
          echo "Error: --list option requires a file argument." >&2
          exit 1
        fi ;;
      --whatif|-if) _DRY_RUN="y" ;;
      *)
        printf "Unknown option (ignored): %s\n" "$1" >&2
        Usage ;;
    esac
    shift
  done
}
main() {
  initialize "$@"
  export_variables

  while read -r SUID; do
      process_suid "$SUID" || break
  done < "$_INPUT_FILE"

  trap - SIGINT  # Reset trap to default behavior
}

main "$@"
