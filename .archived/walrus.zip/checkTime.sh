#!/bin/sh
# shellcheck disable=SC3043
# PURPOSE: A run control script that sleeps if outside of a time window.
# AUTHER: Joel Booth
# DATE: May 2023

if [ -f ./checkLoad.cfg ]; then
	. ./checkLoad.cfg
else
	_OVERRIDE_RUNTIME_HOURS="true"
	runtime_hours="18 19 20 21 22 23 00 01 02 03 04 05"
fi

if [ "$(whoami)" != "medsrv" ]; then
	echo "Script must be run as user: medsrv, exiting"
	exit 1
fi

OutsideRuntimeWindow() {
  # Called like: while OutsideRuntimeWindow; do sleep 1; done
  # 0 = outside of runtime window
  # 1 = within runtime window
	local h
	local hour=$(date "+%H")
	for h  in $runtime_hours; do
    if [ "$hour" == "$h" ]; then
      # printf "\n"
      return 1
    fi
	done
	return 0
}

# printf "%s %s" "$(date)" "Checking time." ; sleep 0.25
# printf "." ; sleep 0.25
# printf "." ; sleep 0.25
# printf "." ; sleep 0.25
while OutsideRuntimeWindow; do
  if [ -f ./checkLoad.cfg ]; then . ./checkLoad.cfg; fi
  if [ "$_OVERRIDE_RUNTIME_HOURS" = "false" ]; then
    printf "Not within runtime hours. Sleeping for 45 minutes.\n"
    sleep 2700 # 45 minutes
  else
    # printf "Runtime hours override is set to true. Continuing.\n"
    break
  fi
done
