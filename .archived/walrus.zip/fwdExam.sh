#!/bin/bash
#shellcheck disable=SC2207,SC1091
# Do not source universal.lib. This script is intended to be self-contained.
# TODO:
#   - Verify required variables

_SCRIPT_NAME="$(basename "$0")"
_SCRIPT_CFG="${_SCRIPT_NAME%.*}.cfg"
_SCRIPT_LOG="${_SCRIPT_NAME%.*}.log"
_DATE_FMT="%Y%m%d-%H%M%S"
_MYSQL_BIN="/home/medsrv/component/mysql/bin/mysql"
_SECURITY_OPT="TCP" # Or TLS
_TLS_OPT="+tls $SSL_SITE_KEY $SSL_SITE_CERT -ic"
# _DRY_RUN="n"
_VERBOSE_OPTS=""
_DEBUG_OPTS=""

# Define Functions
  DisplayUsage() {
    printf "Usage: %s [OPTION]... [SUID]...\n" "$(getScriptName)"
    printf "Forward an exam using runjavacmd.\n"
    printf "\n"
    printf "  -h, --help\t\tDisplay this help and exit\n"
    printf "  -S, -s, --study\tSpecify the SUID of the study to forward\n"
    printf "  --script\t\tUse this option when calling %s from another script\n" "$(getScriptName)"
    printf "  --target\t\tSpecify the target device to forward to\n"
    exit 0
  }
  SetCaseNumber() {
    if [ -z "$crm_case_number" ]; then
      crm_case_number="MigrationsTeam"
    else
      crm_case_number="case_$crm_case_number"
    fi
  }
  verifyTargetDevice(){
      if [[ $TargetVerified = "False" ]]; then
        if [[ -n $(sql.sh "SELECT id FROM Target WHERE id='$TARGET'" -N) ]]; then
        TargetVerified=True
        fi
      fi
  }
  getstudyStatus() {
    local SUID="$1"
    sql.sh "use imagemedical; SELECT mainst FROM Dcstudy WHERE styiuid='$SUID';" -N
  }
  getstudyDicomLocation() {
    "$HOME"/component/repositoryhandler/scripts/locateStudy.sh -d "$SUID"
  }
  getPbRList() {
      local location=$1
      # ls -1tr "${location}" | grep PbR
      find "${location}" -maxdepth 1 -type f -name "*PbR*" -printf "%T@ %p\n" | sort -n | cut -d' ' -f2-
  }
  getNonPbRList() {
      local location=$1
      # ls -1tr "${location}"/ | grep -v PbR
      find "${location}" -maxdepth 1 -type f ! -name '*PbR*' -printf '%T@ %p\n' | sort -n | cut -d' ' -f2-
  }
  Multiple_PbR_Check() {
    # If it has mpbr, attempt to fix it first
    if [[ ${#Study_PbR_List[@]} -gt 1 ]]; then
      if [ "$executedByUser" = "True" ]; then
        printf "%s mpbr %s attempting fix (has %i PbR files).\n" "$(date +"$_DATE_FMT")" "$SUID" "${#Study_PbR_List[@]}"
      elif [ "$executedByUser" = "False" ]; then
        printf "%s mpbr %s attempting fix (has %i PbR files).\n" "$(date +"$_DATE_FMT")" "$SUID" "${#Study_PbR_List[@]}" | tee -a "$(getLogName)"
      fi
      ./fixDupPbR.sh "$SUID" >/dev/null
      Study_PbR_List=($(getPbRList "$Study_Directory"))
    fi
    # The $Study_PbR_List is updated, so check again
    if [[ ${#Study_PbR_List[@]} -gt 1 ]]; then
      if [ "$executedByUser" = "True" ]; then
        printf "%s skipping %s fix attempt failed (has %i PbR files).\n" "$(date +"$_DATE_FMT")" "$SUID" "${#Study_PbR_List[@]}"
      elif [ "$executedByUser" = "False" ]; then
        printf "%s skipping %s fix attempt failed (has %i PbR files).\n" "$(date +"$_DATE_FMT")" "$SUID" "${#Study_PbR_List[@]}" | tee -a "$(getLogName)"
      fi
      sql.sh "USE $migration_database; UPDATE LocalExams SET skip='y', skip_reason='mpbr' WHERE styiuid='$SUID';"
      return 1
    else
      return 0
    fi
  }
  Zero_Object_Study_Check() {
    if [[ ${#Study_NonPbR_List[@]} -eq 0 ]] && [[ ${#Study_PbR_List[@]} -gt 0 ]]; then
      if [ "$executedByUser" = "True" ]; then
        printf "%s skipping %s PbR-Only. Skipping.\n" "$(date +"$_DATE_FMT")" "$Study_Directory"
      elif [ "$executedByUser" = "False" ]; then
        printf "%s skipping %s PbR-Only. Skipping.\n" "$(date +"$_DATE_FMT")" "$Study_Directory"  | tee -a "$(getLogName)"
      fi
      sql.sh "USE $migration_database; UPDATE LocalExams SET skip='y', skip_reason='pbr_only' WHERE styiuid='$SUID';"
      return 1
    elif [[ ${#Study_NonPbR_List[@]} -eq 0 ]]; then
      if [ "$executedByUser" = "True" ]; then
        printf "%s skipping %s has no objects. Skipping.\n" "$(date +"$_DATE_FMT")" "$Study_Directory"
      elif [ "$executedByUser" = "False" ]; then
        printf "%s skipping %s has no objects. Skipping.\n" "$(date +"$_DATE_FMT")" "$Study_Directory"  | tee -a "$(getLogName)"
      fi
      sql.sh "USE $migration_database; UPDATE LocalExams SET skip='y', skip_reason='no_obj' WHERE styiuid='$SUID';"
      return 1
    else
      return 0
    fi
  }
  Study_Status_Check() {
    study_status=$(getstudyStatus "$SUID")
    if (( study_status < 0 )); then
      if [ "$executedByUser" = "True" ]; then
        printf "%s skipping %s is not a valid status. Skipping.\n" "$(date +"$_DATE_FMT")" "$Study_Directory"
      elif [ "$executedByUser" = "False" ]; then
        printf "%s skipping %s is not a valid status. Skipping.\n" "$(date +"$_DATE_FMT")" "$Study_Directory"  | tee -a "$(getLogName)"
      fi
      # TODO: Change hard-coded DB name to variable.
      sql.sh "USE $migration_database; UPDATE LocalExams SET skip='y', skip_reason='bad_status' WHERE styiuid='$SUID';"
      return 1
    else
      return 0
    fi
  }
  Minesweeper() {
    Study_Directory="$(getstudyDicomLocation "$SUID")"
    Study_PbR_List=($(getPbRList "$Study_Directory"))
    Study_NonPbR_List=($(getNonPbRList "$Study_Directory"))
    Multiple_PbR_Check || return 1
    Zero_Object_Study_Check || return 1
    if [ "$executedByUser" = "True" ]; then
      Study_Status_Check || return 1
    fi
  }
  Migrate_Single_Suid() {
    Minesweeper || return 1
    # When called directly by the user
      if [ "$executedByUser" = "True" ] && [ "$TargetVerified" = "True" ]; then
        printf "%s runjavacmd -c \"0 cases.Forward -s %s -H %s -u %s\"\n" "$(date "+%Y%m%d-%H%M%S")" "$SUID" "$TARGET" "$crm_case_number"
        /home/medsrv/component/taskd/runjavacmd -c "0 cases.Forward -s $SUID -H $TARGET -u $crm_case_number"
      elif [ "$executedByUser" = "True" ] && [ "$TargetVerified" = "False" ]; then
        printf "%s %s %s\n" "$(date "+%Y%m%d-%H%M%S")" "$TARGET" "is not a valid target."
    # When called by another script
      elif [ "$executedByUser" = "False" ] && [ "$TargetVerified" = "True" ]; then
        printf "%s runjavacmd -c \"0 cases.Forward -s %s -H %s -u %s\"\n" "$(date "+%Y%m%d-%H%M%S")" "$SUID" "$TARGET" "$crm_case_number" >> "$(getLogName)"
        /home/medsrv/component/taskd/runjavacmd -c "0 cases.Forward -s $SUID -H $TARGET -u $crm_case_number"
      elif [ "$executedByUser" = "False" ] && [ "$TargetVerified" = "False" ]; then
        return 1
      fi
  }
  Migrate_Suid() {
    Minesweeper || return 1
    Check_Required_Variables TARGET crm_case_number SUID
    _date="$(date "+$_DATE_FMT")"
    if [[ "${_DRY_RUN:-n}" == "y" ]]; then
      _date="$_date DRY_RUN"
    fi

    if [ "$_SECURITY_OPT" = "TLS" ]; then
      echo "TLS controlled by device table configuration when using runjavacmd, proceeding."
    fi
    
    # Check combinations of executedByUser and TargetVerified
    if [ "$executedByUser" = "True" ] && [ "$TargetVerified" = "True" ]; then
      printf "%s runjavacmd -c \"0 cases.Forward -s %s -H %s -u %s\"\n" "$_date" "$SUID" "$TARGET" "$crm_case_number" | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN:-n}" == "n" ]]; then
        /home/medsrv/component/taskd/runjavacmd -c "0 cases.Forward -s $SUID -H $TARGET -u $crm_case_number"
      fi
    elif [ "$executedByUser" = "True" ] && [ "$TargetVerified" = "False" ]; then
      printf "%s %s is not a valid target.\n" "$_date" "$TARGET"
    elif [ "$executedByUser" = "False" ] && [ "$TargetVerified" = "True" ]; then
      printf "%s runjavacmd -c \"0 cases.Forward -s %s -H %s -u %s\"\n" "$_date" "$SUID" "$TARGET" "$crm_case_number" >> "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN:-n}" == "n" ]]; then
        /home/medsrv/component/taskd/runjavacmd -c "0 cases.Forward -s $SUID -H $TARGET -u $crm_case_number"
      fi
    elif [ "$executedByUser" = "False" ] && [ "$TargetVerified" = "False" ]; then
      printf "%s Target device %s is not verified. Skipping migration.\n" "$_date" "$TARGET" >> "$_SCRIPT_LOG"
      return 1
    fi
  }
  Check_Required_Variables() {
    # Take a list of variables as arguments and check that they are all set
    # If any are not set, exit with an error
    local var
    for var in "$@"; do
        eval "value=\$$var"
        if [ -z "$value" ]; then
            printf "ERROR: %s is not set\n" "$var" >&2
            exit 1
        fi
    done
  }

executedByUser=True
TargetVerified=False
[ $# -eq 0 ] && DisplayUsage
while [ -n "$1" ]; do
	case $1 in
    --help)   DisplayUsage ;;
    -h)       DisplayUsage ;;
    --whatif) _DRY_RUN="y" ;;
    --script) executedByUser=False ;;
    --target) TARGET="$2"; shift ;;
    --target-verified) TargetVerified=True ;;
    --study)  SUID="$2"; shift ;;
    -S)       SUID="$2"; shift ;;
    -s)       SUID="$2"; shift ;;
    *)        printf "Unknown option (ignored): %s" "$1"; DisplayUsage ;;
  esac
  shift
done

SetCaseNumber
verifyTargetDevice
Migrate_Suid
