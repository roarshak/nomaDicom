#! /bin/bash
#shellcheck disable=SC2207,SC1091

initialize_environment() {
    . $HOME/etc/setenv.sh # TODO: What are we getting from sourcing this? This file is too big to be sourcing every single time.
    . $HOME/var/dicom/pb-scp.cfg  # Load DICOM configuration
    
    _SCRIPT_NAME="moveExam.sh"
    _SCRIPT_CFG="${_SCRIPT_NAME%.*}.cfg"
    _SCRIPT_LOG="${_SCRIPT_NAME%.*}.log"
    _DATE_FMT="%Y%m%d-%H%M%S"
    _MYSQL_BIN="/home/medsrv/component/mysql/bin/mysql"
    _SECURITY_OPT="TCP" # Or TLS
    _TLS_OPT="+tls $SSL_SITE_KEY $SSL_SITE_CERT -ic"
    
    BatchMode="${BatchMode:-false}"
}
Usage() {
  if [[ "${QUIET_MODE}" == "n" ]] && [[ "${BatchMode}" == "false" ]]; then
    printf "Usage: %s [options]\n" "$(basename "$0")"
    printf "Options:\n"
    printf "  --help\t\t\tDisplay this information.\n"
    printf "  -h\t\t\t\tDisplay this information.\n"
    printf "  --script\t\t\tRun as a script.  Do not log to file.\n"
    printf "  --target-ae <AE Title>\t\tThe AE Title of the target device.\n"
    printf "  --source-ae <AE Title>\t\tThe AE Title of the source device.\n"
    printf "  --source-ip <IP Address>\tThe IP Address of the source device.\n"
    printf "  --source-port <Port>\t\tThe Port of the source device.\n"
    printf "  --study <Study UID>\t\tThe Study UID to migrate.\n"
    printf "  -S <Study UID>\t\tThe Study UID to migrate.\n"
    printf "  -s <Study UID>\t\tThe Study UID to migrate.\n"
  fi
  exit 1
}
verifyTargetDevice() {
  # TODO: Source_AET will not work if the source is local
  TargetVerified=False
    if [[ -n $(sql.sh "SELECT AE FROM Target WHERE AE='$Source_AET'" -N) ]]; then
      TargetVerified=True
    else
      Message "Target device $TARGET_DEVICE_NAME cannot be verified. Exiting."
      exit 1
    fi
}
verifySelfAET() {
  if [ -z "$AE_TITLE" ] || ! grep -q "$AE_TITLE" /home/medsrv/var/dicom/pb-scp.cfg; then
    . /home/medsrv/var/dicom/pb-scp.cfg
  fi
}
verifyRequired() {
  if [ -z "$Target_AET" ]; then
    printf "Target AE Title is required.\n"
    Usage
  elif [ -z "$Source_AET" ]; then
    printf "QR AE Title is required.\n"
    Usage
  elif [ -z "$Source_IP" ]; then
    printf "QR IP is required.\n"
    Usage
  elif [ -z "$Source_Port" ]; then
    printf "QR Port is required.\n"
    Usage
  elif [ -z "$SUID" ]; then
    printf "Study UID is required.\n"
    Usage
  fi
}
Migrate_Object() {
  if [[ "$TargetVerified" != "True" ]]; then
    printf "%s %s is not a valid AE Title.\n" "$_date" "$TARGET_AET"
    return 1
  fi
  if [[ "${BatchMode}" == "false" ]]; then
    # use the message function
    Message "movescu" "${_VERBOSE_OPTS}" "${_DEBUG_OPTS}" "${movescu_opts[*]}"
  fi
  if [[ "$QUIET_MODE" = "n" ]]; then
    printf "%s movescu -S --aetitle %s --move %s --key 0008,0052=IMAGE --key 0020,000D=%s --key 0020,000E=%s --key 0008,0018=%s --call %s\n" \
      "$_date" \
      "$AE_TITLE" \
      "$TARGET_AET" \
      "$SUID" \
      "$SERIUID" \
      "$SOPIUID" \
      "$Source_AET $Source_IP $Source_Port" \
      | tee -a "$_SCRIPT_LOG"
  fi
  if [[ "${_DRY_RUN:-n}" == "n" ]]; then
    /home/medsrv/component/dicom/bin/movescu "${movescu_opts[@]}" "$_VERBOSE_OPTS" "$_DEBUG_OPTS" >/dev/null 2>&1
  fi
  if [[ "${_DRY_RUN:-n}" == "n" ]]; then
    /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
      -S \
      --move "$TARGET_AET" \
      --aetitle "$AE_TITLE" \
      --key 0008,0052=IMAGE \
      --key 0020,000D="$SUID" \
      --key 0020,000E="$SERIUID" \
      --key 0008,0018="$SOPIUID" \
      --call $Source_AET $Source_IP $Source_Port
  fi
}
Migrate_Study() {
  # Message "movescu" "${movescu_opts[*]}" "${_VERBOSE_OPTS}" "${_DEBUG_OPTS}"
  Message "movescu" "${movescu_opts[*]}"
  /home/medsrv/component/dicom/bin/movescu "${movescu_opts[@]}"
}
Migrate_Suid() {
  _date="$(date "+$_DATE_FMT")"
  [[ "${_DRY_RUN:-n}" == "y" ]] && _date="${_date} DRY_RUN"

  # Initialize movescu_opts with common options
  movescu_opts=("-S" "--aetitle"  "$AE_TITLE" "--key" "0008,0052=STUDY")

  # Add specific options for this migration
  movescu_opts+=("--move" "$Target_AET")
  movescu_opts+=("--call" "$Source_AET" "$Source_IP" "$Source_Port")
  movescu_opts+=("--key" "0020,000d=$SUID")

  # Add security options if needed
  if [ "$_SECURITY_OPT" = "TLS" ]; then
    Check_Required_Variables SSL_SITE_KEY SSL_SITE_CERT _TLS_OPT
    movescu_opts+=("$_TLS_OPT")
  fi

  # Add series and SOP instance UID keys if available
  if [ -n "$SERIUID" ] && [ -n "$SOPIUID" ]; then
    movescu_opts+=("--key" "0020,000E=$SERIUID" "--key" "0008,0018=$SOPIUID")
  fi

  Migrate_Study
}
main() {
    QUIET_MODE="n"  # Default to not quiet
    [ $# -eq 0 ] && Usage
    while [ -n "$1" ]; do
      case $1 in
        --study|-S|-s) SUID="$2"; shift ;; #REQUIRED
        --target-ae) Target_AET="$2"; shift ;; #REQUIRED
        --source-ae) Source_AET="$2"; shift ;; #REQUIRED
        --source-ip) Source_IP="$2"; shift ;; #REQUIRED
        --source-port) Source_Port="$2"; shift ;; #REQUIRED
        --series) SERIUID="$2"; shift ;; #OPTIONAL
        --instance) SOPIUID="$2"; shift ;; #OPTIONAL
        --quiet) QUIET_MODE="true" ;;
        --whatif) _DRY_RUN="y" ;;
        --help|-h) Usage ;;
        --script) executedByUser=False ;;
        *)        
            if [[ "$QUIET_MODE" != "y" ]]; then
                printf "Unknown option (ignored): %s\n" "$1"; 
            fi
            Usage ;;
      esac
      shift
    done

    # Environment checks and preparations
    initialize_environment
    verifySelfAET
    verifyTargetDevice

    # Core functionality
    Migrate_Suid
}

main "$@"
