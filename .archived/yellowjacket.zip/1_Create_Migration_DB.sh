#!/bin/bash
#shellcheck disable=SC2207,SC1091

# Define Variables
  MYSQL_BIN="/home/medsrv/component/mysql/bin/mysql"

  check_and_source_config() {
    while [ -n "$1" ]; do
      if [[ -f "$1" ]]; then
        . "$1"
      else
        echo "ERROR: Could not find $1. Exiting."
        exit 1
      fi
      shift
    done
  }
check_and_source_config "$HOME/etc/setenv.sh"
check_and_source_config "universal.lib" "universal.cfg"

# Define Functions
  user_check () {
    # Exit if not running as medsrv user
    if [[ $USER != "medsrv" ]]; then 
      echo "This script must be run as medsrv!" 
      exit 1
    fi
  }
  Check_Required_Variables() {
    # Take a list of variables as arguments and check that they are all set
    # If any are not set, exit with an error
    local var
    for var in "$@"; do
        eval "value=\$$var"
        if [ -z "$value" ]; then
            printf "ERROR: %s is not set\n" "$var" >&2
            exit 1
        fi
    done
  }
  Create_Fwdexams_Db() {
    # Database Functions
    if ! "$MYSQL_BIN" -BN -u root -p"$MYSQL_ROOT_PW" -e "GRANT ALL PRIVILEGES ON $migration_database.* TO 'medsrv'@'localhost';"; then
      echo "Mysql command error, exiting."
      exit 1
    fi
    # execute_mysql_command "GRANT ALL PRIVILEGES ON $migration_database.* TO 'medsrv'@'localhost';"
    
    if ! "$MYSQL_BIN" -BN -u root -p"$MYSQL_ROOT_PW" -e "FLUSH PRIVILEGES;"; then
      echo "Mysql command error, exiting."
      exit 1
    fi
    # execute_mysql_command "FLUSH PRIVILEGES;"
    
    if ! "$MYSQL_BIN" -BN -u root -p"$MYSQL_ROOT_PW" -e "CREATE DATABASE IF NOT EXISTS $migration_database;"; then
      echo "Mysql command error, exiting."
      exit 1
    fi
    # execute_mysql_command "CREATE DATABASE IF NOT EXISTS $migration_database;"
  }
  Create_Localexams_Tbl() {
    "$MYSQL_BIN" -BN -D "$migration_database" -e "
      DROP TABLE IF EXISTS LocalExams;
      CREATE TABLE LocalExams (
          styiuid char(100) UNIQUE KEY,
          numofobj smallint(5) DEFAULT '0',
          sumsize bigint(20) DEFAULT 0,
          migrate enum('y','n') DEFAULT 'n',
          study_date datetime DEFAULT NULL,
          transferred_datetime datetime DEFAULT NULL,
          verification enum('pass','fail','pending') DEFAULT NULL,
          skip enum('y','n') DEFAULT 'n',
          skip_reason enum('mpbr','bad_dir','no_obj','bad_status','vfail','copy','shortcut','pbr_only','deleted') DEFAULT NULL,
          export_location varchar(255) DEFAULT NULL,
          INDEX xnumofobj (numofobj)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8;"
  }
  prompt() {
    read -rp "The database will be $migration_database. Accept and continue? (y/n) " -n 1 -r
    echo
    [[ ! $REPLY =~ ^[Yy]$ ]] && exit 1
  }
  main() {
    prompt
    Create_Fwdexams_Db
    Create_Localexams_Tbl
  }

user_check
Check_Required_Variables migration_database MYSQL_ROOT_PW
main
