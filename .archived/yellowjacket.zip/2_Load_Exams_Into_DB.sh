#!/bin/bash

# Define Variables
  MYSQL_BIN="/home/medsrv/component/mysql/bin/mysql"

  check_and_source_config() {
    while [ -n "$1" ]; do
      if [[ -f "$1" ]]; then
        . "$1"
      else
        echo "ERROR: Could not find $1. Exiting."
        exit 1
      fi
      shift
    done
  }
check_and_source_config "universal.lib" "universal.cfg"

check_and_source_files() {
    local script_name=$(basename "$0" .sh) # Get the script's base name without '.sh'
    local config_file="universal.cfg"
    local lib_file="universal.lib"
    local local_config="${script_name}.cfg"

    # Check for universal.cfg
    if [ -f "$config_file" ]; then
        # echo "Sourcing $config_file..."
        . "$config_file"
    else
        # Create a script-specific config file if universal.cfg is not found
        if [ ! -f "$local_config" ]; then
            echo "# Script-specific configuration variables" > "$local_config"
            echo "VAR1='Define me'" >> "$local_config"
            echo "VAR2='Define me'" >> "$local_config"
            echo "$local_config has been created. Please define the required variables."
        else
            source "$local_config"
        fi
    fi

    # Check for universal.lib
    if [ -f "$lib_file" ]; then
        echo "Sourcing $lib_file..."
        source "$lib_file"
    else
        echo "Warning: $lib_file not found. Ensure shared functions are available."
    fi
}

# Define Functions
  DisplayUsage() {
    echo "Usage: $(getScriptName) [options]"
    echo "Options:"
    echo "  --help, -h        Display this help message and exit"
    echo "  --list, -l        List of SUIDs in scope"
    exit 1
  }
  user_check () {
    # Exit if not running as medsrv user
    if [[ $USER != "medsrv" ]]; then 
      echo "This script must be run as medsrv!" 
      exit 1
    fi
  }
  Check_Required_Variables() {
    # Take a list of variables as arguments and check that they are all set
    # If any are not set, exit with an error
    local var
    for var in "$@"; do
        eval "value=\$$var"
        if [ -z "$value" ]; then
            printf "ERROR: %s is not set\n" "$var" >&2
            exit 1
        fi
    done
  }
  Insert_All_Local_Exams_To_Db() {
    # Pushing to erad:        Yes
    # Pushing to non-erad:    Yes
    # Pulling from erad:      Yes
    # Pulling from non-erad:  Yes
    # Exporting to disk:      Yes
    # Importing from disk:    Yes
    local studydate_column
    studydate_column="$("$MYSQL_BIN" -BN -D imagemedical -e "describe Dcstudy" | grep -i ^stydate | awk '{print $1}')"
    Check_Required_Variables studydate_column
    "$MYSQL_BIN" -D "$migration_database" -e "
      INSERT INTO LocalExams (styiuid, numofobj, sumsize, study_date)
      SELECT STYIUID, NUMOFOBJ, SUMSIZE, DATE($studydate_column)
      FROM imagemedical.Dcstudy
      WHERE mainst>='0' AND Dcstudy_d!='yes';"
  }
  Update_Db_Via_List_Set_Suid_Inscope() {
      [ ! -f "$ListOf_SUIDS_In_Scope" ] && { echo "ERROR: $ListOf_SUIDS_In_Scope does not exist. Exiting."; exit 1; }
      while IFS= read -r styiuid; do
        "$MYSQL_BIN" -D "$migration_database" -e "
          UPDATE    LocalExams
            SET       migrate='y'
            WHERE     styiuid='$styiuid' AND
                      migrate='n';"
      done < "$ListOf_SUIDS_In_Scope"
  }
  Update_Db_For_Shortcuts_And_Copies() {
    "$MYSQL_BIN" -D "$migration_database" -e "UPDATE LocalExams SET skip='y', skip_reason='shortcut' WHERE styiuid IN (SELECT styiuid FROM imagemedical.Dcstudy WHERE derived='shortcut');"
    "$MYSQL_BIN" -D "$migration_database" -e "UPDATE LocalExams SET skip='y', skip_reason='copy' WHERE styiuid IN (SELECT styiuid FROM imagemedical.Dcstudy WHERE derived='copy');"
  }
  Update_Db_For_Deleted_Exams() {
    "$MYSQL_BIN" -D "$migration_database" -e "UPDATE LocalExams SET skip='y', skip_reason='deleted' WHERE styiuid IN (SELECT styiuid FROM imagemedical.Dcstudy WHERE Dcstudy_D='yes');"
  }
  main() {
    Insert_All_Local_Exams_To_Db
    Update_Db_Via_List_Set_Suid_Inscope
    # Update_Db_For_Shortcuts_And_Copies
  }

user_check
[ $# -eq 0 ] && DisplayUsage
while [ -n "$1" ]; do
	case $1 in
    --help|-h)   DisplayUsage ;;
    --list|-l)       ListOf_SUIDS_In_Scope="$2"; shift ;;
    *)        printf "Unknown option (ignored): %s" "$1"; DisplayUsage ;;
  esac
  shift
done

Check_Required_Variables MYSQL_BIN migration_database ListOf_SUIDS_In_Scope
main
