#!/bin/bash

# Expected GLOBAL variables
_WDIR
_MIGRATION_DATABASE
Migration_Mode
_Case_Number_Ecm
Source_Label
Source_IP
Source_AET
Source_Port
Target_Label
Target_IP
Target_AET
Target_Port
Export_Directory

# Optionally dependent variables
StartDate
StopDate