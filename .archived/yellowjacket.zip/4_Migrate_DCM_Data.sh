#!/bin/bash
# TODO: implement custom GETOPTS
# TODO: Force migration type selection with GETOPTS
# TODO: Review arguments to check_and_source_config for necessity
# TODO: Review Check_Required_Variables
# TODO: Replace all instances of sql.sh with "$MYSQL_BIN" -BN -D "$migration_database" -e

  check_and_source_config() {
    while [ -n "$1" ]; do
      if [[ -f "$1" ]]; then
        . "$1"
      else
        echo "ERROR: Could not find $1. Exiting."
        exit 1
      fi
      shift
    done
  }
check_and_source_config "$HOME/etc/setenv.sh"
check_and_source_config "${DICOM_VAR}/pb-scp.cfg" "${VAR}/conf/limit.conf" "${VAR}/conf/self.rec" "${VAR}/conf/serverid.cfg" "${VAR}/conf/site.conf"
check_and_source_config "universal.lib" "universal.cfg"

# Define Variables
  MYSQL_BIN="/home/medsrv/component/mysql/bin/mysql"
  SleepTime=10
  chunkSize=5

# Define Functions
  Update_Local_Exams_Transferred_Datetime() {
      local suid
      suid="$1"
      local current_datetime
      current_datetime=$(date +"%Y-%m-%d %H:%M:%S")
      "$MYSQL_BIN" -BN -D "$migration_database" -e "
          UPDATE    LocalExams
          SET       transferred_datetime='$current_datetime',
                    verification='pending'
          WHERE     styiuid='$suid';"
  }
  Get_Next_Exam_To_Migrate() {
    "$MYSQL_BIN" -BN -D "$migration_database" -e "
      SELECT styiuid
      FROM LocalExams
      WHERE
            migrate='y' AND
            verification IS NULL AND
            transferred_datetime IS NULL
      ORDER BY numofobj DESC
      LIMIT 1;"
  }
  Check_Load() {
    if [[ $chunk -ge $chunkSize ]]; then
      chunk="0"
      "$(pwd)"/checkLoad.sh
    fi
  }


##########################
# DICOM TRANSFER FUNCTIONS
  Migrate_List() {
    Check_Required_Variables migration_target
    target_aet="$(sql.sh "SELECT ae FROM Target where id='$migration_target'" -N)"
    target_ip="$(sql.sh "SELECT host FROM Target where id='$migration_target'" -N)"
    target_port="$(sql.sh "SELECT port FROM Target where id='$migration_target'" -N)"
    chunk="$chunkSize"
    while :; do
        suid="$(Get_Next_Exam_To_Migrate)"
        [[ -z $suid ]] && break
        if ./cmpObjCnt.sh --study "$suid" --target-aet "$target_aet" --target-ip "$target_ip" --target-port "$target_port"; then
          Check_Load
          ((count++)); ((chunk++))
          printf "%s runjavacmd -c \"0 cases.Forward -s %s -H %s -u case_%s\"\n" "$(date)" "$suid" "$migration_target" "$crm_case_number"
          ./fwdExam.sh --script --target-verified --target "$migration_target" --study "$suid"
            # fwdExam.sh logs to its own log file
            # runjavacmd -c "0 cases.Forward -s $suid -H $migration_target -u case_$crm_case_number"
          Update_Local_Exams_Transferred_Datetime "$suid"
          sleep "$SleepTime"
        else
          printf "%s Study %s is already migrated.\n" "$(date)" "$suid"
          sql.sh "USE $migration_database; UPDATE LocalExams SET verification='pass' WHERE styiuid='$suid';"
        fi
    done
  }
  Retrieve_By_Date_Range_Via_Cfind() {
    # For Pulling from non-eRAD PACS
    printf "My function name is %s\n" "${FUNCNAME[0]}"
    printf %s" Migrating from $SOURCE to $migration_target\n"
    sleep 3
  }
  Export_To_Disk() {
    Check_Required_Variables Export_Root_Dir
    chunk="$chunkSize"
    while :; do
        suid="$(Get_Next_Exam_To_Migrate)"
        [[ -z $suid ]] && break
        Check_Load
        ((count++)); ((chunk++))
        ./exportExam.sh --script --target "$Export_Root_Dir" --study "$suid"
        Update_Local_Exams_Transferred_Datetime "$suid"
        sleep "$SleepTime"
    done
  }
  Import_From_Disk() {
    printf "My function name is %s\n" "${FUNCNAME[0]}"
    printf %s" Migrating from $SOURCE to $migration_target\n"
    sleep 3
  }

# MAIN
# usage check
user_check
Check_Required_Variables MYSQL_BIN crm_case_number migration_database
Migrate_List
# Export_To_Disk
