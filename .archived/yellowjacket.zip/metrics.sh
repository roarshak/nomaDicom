#!/bin/bash

# Define Functions
  Return_IsDateValid() { date -d "$1" "+%m/%d/%Y" >/dev/null 2>&1; }
  Return_DoesDatabaseExist() { echo "show databases;" | /home/medsrv/component/mysql/bin/mysql | grep -wqs "$1"; }
  check_and_source_config() {
    while [ -n "$1" ]; do
      if [[ -f "$1" ]]; then
        . "$1"
      else
        echo "ERROR: Could not find $1. Exiting."
        exit 1
      fi
      shift
    done
  }
  automatic() {
    # Get Dates
      start_datetime="$(sql.sh "SELECT MIN(transferred_datetime) FROM $migration_database.LocalExams;" -N)"
      end_datetime="$(sql.sh "SELECT MAX(transferred_datetime) FROM $migration_database.LocalExams;" -N)"
    # Are date variable values valid
      if ! Return_IsDateValid "$start_datetime"; then
        echo "Start date ($start_datetime) is invalid. Exiting."
        exit 1
      fi
      if ! Return_IsDateValid "$end_datetime"; then
        echo "End date ($end_datetime) is invalid. Exiting."
        exit 1
      fi

    # Get Exam Counts
      total_exams="$(sql.sh "SELECT COUNT(*) FROM $migration_database.LocalExams WHERE transferred_datetime IS NOT NULL;" -N)"
      remaining_exams="$(sql.sh "SELECT COUNT(*) FROM $migration_database.LocalExams WHERE migrate='y' AND verification IS NULL AND transferred_datetime IS NULL;" -N)"

    # Exam counts must be non-zero to continue
      if [ "$total_exams" -eq 0 ]; then
        echo "No exams have been migrated yet, unable to calculate. Exiting."
        exit 1
      fi
      if [ "$remaining_exams" -eq 0 ]; then
        echo "All exams have been migrated. Exiting."
        exit 1
      fi

    # Convert datetimes to epoch seconds
      start_epoch=$(date -d "$start_datetime" "+%s")
      end_epoch=$(date -d "$end_datetime" "+%s")

    # Calculate total minutes between start and end datetimes
      total_minutes=$(( (end_epoch - start_epoch) / 60 ))

    # Calculate average exams per minute
      average_exams_per_minute=$(bc <<< "scale=2; $total_exams / $total_minutes")

    # Calculate average exams per day
      average_exams_per_day=$(bc <<< "scale=2; $total_exams / (($end_epoch - $start_epoch) / 86400)")

    # Calculate projected finish date based on average exams per minute and remaining exams
      remaining_minutes=$(bc <<< "scale=0; $remaining_exams / $average_exams_per_minute")
      projected_finish_epoch=$((end_epoch + (remaining_minutes * 60)))
      projected_finish_date=$(date -d "@$projected_finish_epoch" "+%Y-%m-%d %H:%M:%S")
  }
  manual() {
    # Prompt user for input
    read -p "Enter start date (YYYY-MM-DD): " start_date
    read -p "Enter start time (HH:MM): " start_time
    read -p "Enter starting number of exams: " start_exams
    read -p "Enter end date (YYYY-MM-DD): " end_date
    read -p "Enter end time (HH:MM): " end_time
    read -p "Enter ending number of exams: " end_exams
    read -p "Enter number of exams remaining: " remaining_exams

    # Combine start date and time into one variable
    start_datetime="$start_date $start_time"

    # Combine end date and time into one variable
    end_datetime="$end_date $end_time"

    # Convert datetimes to epoch seconds
    start_epoch=$(date -d "$start_datetime" "+%s")
    end_epoch=$(date -d "$end_datetime" "+%s")

    # Calculate total minutes between start and end datetimes
    total_minutes=$(( (end_epoch - start_epoch) / 60 ))

    # Calculate total exams between start and end datetimes
    total_exams=$((end_exams - start_exams))

    # Calculate average exams per minute
    average_exams_per_minute=$(bc <<< "scale=2; $total_exams / $total_minutes")

    # Calculate average exams per day
    average_exams_per_day=$(bc <<< "scale=2; $total_exams / (($end_epoch - $start_epoch) / 86400)")

    # Calculate projected finish date based on average exams per minute and remaining exams
    remaining_minutes=$(bc <<< "scale=0; $remaining_exams / $average_exams_per_minute")
    projected_finish_epoch=$((end_epoch + (remaining_minutes * 60)))
    projected_finish_date=$(date -d "@$projected_finish_epoch" "+%Y-%m-%d %H:%M:%S")
  }
  extraInfo() {
    sql.sh "USE $migration_database; SELECT 
      (SELECT COUNT(STYIUID) FROM LocalExams) AS Total,
      (SELECT COUNT(*) FROM LocalExams WHERE migrate='y') AS Enabled,
      (SELECT COUNT(*) FROM LocalExams WHERE migrate='n') AS Not_Enabled,
      (SELECT COUNT(*) FROM LocalExams WHERE transferred_datetime IS NOT NULL) AS Transferred,
      (SELECT COUNT(*) FROM LocalExams WHERE transferred_datetime IS NULL) AS Transferred_ISNULL,
      (SELECT COUNT(*) FROM LocalExams WHERE verification='pass') AS Verify_Pass,
      (SELECT COUNT(*) FROM LocalExams WHERE verification='fail') AS Verify_Fail,
      (SELECT COUNT(*) FROM LocalExams WHERE verification IS NULL) AS Verify_ISNULL,
      (SELECT ROUND(AVG(MOVED)) FROM (
        SELECT DATE(transferred_datetime) AS DATE, count(*) AS MOVED
        FROM LocalExams
        WHERE transferred_datetime IS NOT NULL
        GROUP BY DATE(transferred_datetime)
      ) AS Daily_Average) AS Daily_Avg;
    " -t
  }
  DisplayResults() {
    # Display results in desired format
    echo "###########################################"
    echo "Run-rate Projections For $(date "+%Y-%m-%d %H:%M")"
    echo "Please note that the progress percentage mentioned here pertains specifically to the primary stage of migration and validation."
    echo "Additional phases may be necessary to rectify any exams that did not transfer successfully during the initial attempt."
    echo "-------------------------------------------"
    echo "$(date -d "$start_datetime" "+%Y-%m-%d %H:%M") - $(date -d "$end_datetime" "+%Y-%m-%d %H:%M")"
    echo "$total_exams exams in $total_minutes minutes ($((total_minutes / 1440)) days)"
    echo "Averaged $(printf "%.2f" $average_exams_per_minute) exams per minute ($(printf "%.2f" $average_exams_per_day) per day)"
    echo "Projected finish date is $projected_finish_date"
  }

[ -f universal.lib ] && check_and_source_config universal.lib
[ -f universal.cfg ] && check_and_source_config universal.cfg

# TODO: Add GETOPTS to catch a --manual options should the user want it
# TODO: Add GETOPTS for basic output

Check_Required_Variables
if Return_DoesDatabaseExist "$migration_database" ; then
  # Calculate with automatic
  automatic
  DisplayResults
  extraInfo
else
  # Calculate with manual
  manual
  DisplayResults
fi
