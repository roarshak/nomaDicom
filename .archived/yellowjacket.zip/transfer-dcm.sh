#!/bin/bash
#shellcheck disable=SC2207,SC1091
DisplayUsage() {
  {
    printf "Usage: %s [OPTION]... [METHOD]... [SUID]...\n" "$(basename "$0")"
    printf "\n"
    printf "  -h, --help\t\tDisplay this help and exit\n"
    printf "  -M, --method\tSpecify the method of study transfer\n"
    printf "      move\n"
    printf "      moveobj\n"
    printf "        --series  \tSpecify the SERIUID of the object to transfer\n"
    printf "        --instance\tSpecify the SOPIUID of the object to transfer\n"
    printf "      storeobj\n"
    printf "        -O, --obj\tSpecify the Filename of the object to transfer\n"
    printf "      get\n"
    printf "      forward\n"
    printf "  --tls\tSpecify the security level of the transfer (TCP or TLS)\n"
    printf "  -S, --study\tSpecify the SUID of the study to transfer\n"
    printf "  --script\t\tDo not log results to a file\n"
  } >&2  # Redirects all output of this block to stderr
  exit 0
}
check_and_source_config() {
  while [ -n "$1" ]; do
    if [[ -f "$1" ]]; then
      # shellcheck disable=SC1090
      . "$1"
    else
      echo "ERROR: Could not find $1. Exiting."
      exit 1
    fi
    shift
  done
}
getOptions() {
  executedByUser=True
  [ $# -eq 0 ] && DisplayUsage
  while [ -n "$1" ]; do
    case $1 in
      --help|-h)   DisplayUsage ;;
      --verbose|-v)  _VERBOSE_OPTS="--verbose" ;;
      --debug|-d)  _DEBUG_OPTS="--debug" ;;
      --script)
        # shellcheck disable=SC2034
        executedByUser=False ;;
      --method|-M)  _METHOD="$2"; shift ;;
      --series)  SERIUID="$2"; shift ;;
      --instance)  SOPIUID="$2"; shift ;;
      --obj|-O)  DCM_Filename="$2"; shift ;;
      --calling-aet) AE_TITLE="$2"; shift ;;
      --tls)  _SECURITY_OPT="$2"; shift ;;
      --study|-S)  SUID="$2"; shift ;;
      --whatif|-if)  _DRY_RUN="y" ;;
      *)        printf "Unknown option (ignored): %s" "$1"; DisplayUsage ;;
    esac
    shift
  done
}
main() {
  if [ "$_METHOD" = "move" ]; then
    Check_Required_Variables AE_TITLE TARGET_AET QRAE_TITLE QRIP QRPORT SUID
    _date="$(date "+$_DATE_FMT")"
    if [[ "${_DRY_RUN}" == "y" ]]; then
      _date="$_date DRY_RUN"
    fi
    if [ "$_SECURITY_OPT" = "TCP" ]; then
      printf "%s movescu $_VERBOSE_OPTS $_DEBUG_OPTS -S --aetitle %s --move %s --key 0008,0052=STUDY --key 0020,000D=%s --call %s \n" \
        "$_date" \
        "$AE_TITLE" \
        "$TARGET_AET" \
        "$SUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        # tail -f "$_SCRIPT_LOG" &
        # TAIL_PID=$!
        /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
          -S \
          --move "$TARGET_AET" \
          --aetitle "$AE_TITLE" \
          --key 0008,0052=STUDY \
          --key 0020,000d="$SUID" \
          --call $QRAE_TITLE $QRIP $QRPORT \
          > "$_SCRIPT_LOG" 2>&1
        # kill "$TAIL_PID" 2>/dev/null
      fi
    elif [ "$_SECURITY_OPT" = "TLS" ]; then
      Check_Required_Variables SSL_SITE_KEY SSL_SITE_CERT _TLS_OPT
      printf "%s movescu %s -S --aetitle %s --move %s --key 0008,0052=STUDY --key 0020,000D=%s --call %s \n" \
        "$_date" \
        "$_TLS_OPT" \
        "$AE_TITLE" \
        "$TARGET_AET" \
        "$SUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        /home/medsrv/var/openssl/bin/ssl_pp | \
          /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
            $_TLS_OPT \
            -S \
            --move "$TARGET_AET" \
            --aetitle "$AE_TITLE" \
            --key 0008,0052=STUDY \
            --key 0020,000d="$SUID" \
            --call $QRAE_TITLE $QRIP $QRPORT
      fi
    fi
  elif [ "$_METHOD" = "moveobj" ]; then
    Check_Required_Variables DCM_Filename SERIUID SOPIUID
    Check_Required_Variables AE_TITLE TARGET_AET QRAE_TITLE QRIP QRPORT SERIUID SOPIUID SUID
    _date="$(date "+$_DATE_FMT")"
    if [[ "${_DRY_RUN}" == "y" ]]; then
      _date="$_date DRY_RUN"
    fi
    if [ "$_SECURITY_OPT" = "TCP" ]; then
      printf "%s movescu -S --aetitle %s --move %s --key 0008,0052=IMAGE --key 0020,000D=%s --key 0020,000E=%s --key 0008,0018=%s --call %s \n" \
        "$_date" \
        "$AE_TITLE" \
        "$TARGET_AET" \
        "$SUID" \
        "$SERIUID" \
        "$SOPIUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
          -S \
          --move "$TARGET_AET" \
          --aetitle "$AE_TITLE" \
          --key 0008,0052=IMAGE \
          --key 0020,000D="$SUID" \
          --key 0020,000E="$SERIUID" \
          --key 0008,0018="$SOPIUID" \
          --call $QRAE_TITLE $QRIP $QRPORT
      fi
    elif [ "$_SECURITY_OPT" = "TLS" ]; then
      Check_Required_Variables SSL_SITE_KEY SSL_SITE_CERT _TLS_OPT
      printf "%s movescu %s -S --aetitle %s --move %s --key 0008,0052=IMAGE --key 0020,000D=%s --key 0020,000E=%s --key 0008,0018=%s --call %s \n" \
        "$_date" \
        "$_TLS_OPT" \
        "$AE_TITLE" \
        "$TARGET_AET" \
        "$SUID" \
        "$SERIUID" \
        "$SOPIUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
          $_TLS_OPT \
          -S \
          --move "$TARGET_AET" \
          --aetitle "$AE_TITLE" \
          --key 0008,0052=IMAGE \
          --key 0020,000D="$SUID" \
          --key 0020,000E="$SERIUID" \
          --key 0008,0018="$SOPIUID" \
          --call $QRAE_TITLE $QRIP $QRPORT
      fi
    fi
  elif [ "$_METHOD" = "storeobj" ]; then
    Check_Required_Variables DCM_Filename
    SUID="$(sql.sh "select styiuid from Dcobject where fname='$DCM_Filename'" -N)"
    SERIUID="$(sql.sh "select seriuid from Dcobject where fname='$DCM_Filename'" -N)"
    SOPIUID="$(sql.sh "select sopiuid from Dcobject where fname='$DCM_Filename'" -N)"
    Check_Required_Variables AE_TITLE TARGET_AET QRAE_TITLE QRIP QRPORT SERIUID SOPIUID SUID
    _date="$(date "+$_DATE_FMT")"
    if [[ "${_DRY_RUN}" == "y" ]]; then
      _date="$_date DRY_RUN"
    fi
    if [ "$_SECURITY_OPT" = "TCP" ]; then
      printf "%s movescu -S --aetitle %s --move %s --key 0008,0052=IMAGE --key 0020,000D=%s --key 0020,000E=%s --key 0008,0018=%s --call %s \n" \
        "$_date" \
        "$AE_TITLE" \
        "$TARGET_AET" \
        "$SUID" \
        "$SERIUID" \
        "$SOPIUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
          -S \
          --move "$TARGET_AET" \
          --aetitle "$AE_TITLE" \
          --key 0008,0052=IMAGE \
          --key 0020,000D="$SUID" \
          --key 0020,000E="$SERIUID" \
          --key 0008,0018="$SOPIUID" \
          --call $QRAE_TITLE $QRIP $QRPORT
      fi
    elif [ "$_SECURITY_OPT" = "TLS" ]; then
      Check_Required_Variables SSL_SITE_KEY SSL_SITE_CERT _TLS_OPT
      printf "%s movescu %s -S --aetitle %s --move %s --key 0008,0052=IMAGE --key 0020,000D=%s --key 0020,000E=%s --key 0008,0018=%s --call %s \n" \
        "$_date" \
        "$_TLS_OPT" \
        "$AE_TITLE" \
        "$TARGET_AET" \
        "$SUID" \
        "$SERIUID" \
        "$SOPIUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        /home/medsrv/component/dicom/bin/movescu $_VERBOSE_OPTS $_DEBUG_OPTS \
          $_TLS_OPT \
          -S \
          --move "$TARGET_AET" \
          --aetitle "$AE_TITLE" \
          --key 0008,0052=IMAGE \
          --key 0020,000D="$SUID" \
          --key 0020,000E="$SERIUID" \
          --key 0008,0018="$SOPIUID" \
          --call $QRAE_TITLE $QRIP $QRPORT
      fi
    fi
  elif [ "$_METHOD" = "get" ]; then
    Check_Required_Variables AE_TITLE QRAE_TITLE QRIP QRPORT SUID
    _date="$(date "+$_DATE_FMT")"
    if [[ "${_DRY_RUN}" == "y" ]]; then
      _date="$_date DRY_RUN"
    fi
    if [ "$_SECURITY_OPT" = "TCP" ]; then
      printf "%s getscu -S --aetitle %s --key QueryRetrieveLevel=STUDY --key StudyInstanceUID=%s --call %s \n" \
        "$_date" \
        "$AE_TITLE" \
        "$SUID" \
        "$QRAE_TITLE $QRIP $QRPORT" \
        | tee -a "$_SCRIPT_LOG"
      if [[ "${_DRY_RUN}" == "n" ]]; then
        /home/medsrv/component/dicom/bin/getscu $_VERBOSE_OPTS $_DEBUG_OPTS \
          -aet "$AE_TITLE" \
          --key QueryRetrieveLevel=STUDY \
          --key StudyInstanceUID="$SUID" \
          -aec $QRAE_TITLE $QRIP $QRPORT
      fi
    elif [ "$_SECURITY_OPT" = "TLS" ]; then
      echo "TLS not supported for getscu"
      exit 1
    fi
  elif [ "$_METHOD" = "forward" ]; then
    Check_Required_Variables TARGET_DEVICE_NAME crm_case_number SUID
    _date="$(date "+$_DATE_FMT")"
    if [[ "${_DRY_RUN}" == "y" ]]; then
      _date="$_date DRY_RUN"
    fi
    if [ "$_SECURITY_OPT" = "TLS" ]; then
      echo "TLS controlled by device table configuration when using runjavacmd, proceeding."
    fi
    printf "%s runjavacmd -c \"0 cases.Forward -s %s -H %s -u %s \n" \
      "$_date" \
      "$SUID" \
      "$TARGET_DEVICE_NAME" \
      "$crm_case_number" \
      | tee -a "$_SCRIPT_LOG"
    if [[ "${_DRY_RUN}" == "n" ]]; then
      /home/medsrv/component/taskd/runjavacmd \
        -c "0 cases.Forward -s $SUID -H $TARGET_DEVICE_NAME -u $crm_case_number"
    fi
  fi
}

crm_case_number=""
_SCRIPT_NAME="$(basename "$0")"
_SCRIPT_CFG="${_SCRIPT_NAME%.*}.cfg"
_SCRIPT_LOG="${_SCRIPT_NAME%.*}.log"
_DATE_FMT="%Y%m%d-%H%M%S"
_MYSQL_BIN="/home/medsrv/component/mysql/bin/mysql"
_SECURITY_OPT="TCP" # Or TLS
_TLS_OPT="+tls $SSL_SITE_KEY $SSL_SITE_CERT -ic"
_VERBOSE_OPTS=""
_DEBUG_OPTS=""
_DRY_RUN="n"

check_and_source_config "universal.lib" "universal.cfg"
check_and_source_config "$_SCRIPT_CFG"
Check_Required_Variables _METHOD

getOptions "$@"
main
