# 2_Load_Exams_Into_DB.sh

```mermaid
graph TD
    %% Define nodes
    A[Start] --> B
    B{Which StyDt Column?}
    subgraph Insert Into Database
      C["INSERT INTO LocalExams (styiuid, numofobj, sumsize, study_date)
        SELECT STYIUID, NUMOFOBJ, SUMSIZE, DATE($studydate_column)
        FROM imagemedical.Dcstudy
        WHERE mainst >= '0' AND Dcstudy_d != 'yes';"]
    end
    subgraph Update In-Scope Exams
      D["UPDATE LocalExams
        SET migrate='y'
        WHERE styiuid='$styiuid' AND migrate='n';"]
    end
    B -->|DATE| C
    B -->|DATETIME| C
    C --> D

    %% Style nodes
    style B fill:#f96,stroke:#333,stroke-width:2px

    classDef leftalign text-align:left;
    class C,D leftalign;
```