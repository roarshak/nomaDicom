# migloop.sh

```mermaid
graph TD
    readInputFile(Read Input File) --> skipProcessed{Skip If Processed}
    skipProcessed -->|Already Processed| readInputFile
    skipProcessed -->|Not Processed| checkLoad(Check Load)
    checkLoad --> transferActual[DICOM Transfer] --> waitImages[Wait For Images]
    waitImages --> readInputFile

    click readInputFile callback "tooltip"
    click skipProcessed "https://www.github.com" "This is a link"
```
