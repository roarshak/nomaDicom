#!/bin/bash
DisplayUsage() {
  {
    printf "Usage: %s [OPTION]... [METHOD]... [SUID]...\n" "$(getScriptName)"
    printf "\n"
    printf "  -h, --help\t\tDisplay this help and exit\n"
    printf "  -L, --list\tSpecify the file containing the list of SUIDs to transfer\n"
    printf "  -if, --whatif\t\tDry run, do not actually transfer\n"
    printf "  -v, --verbose\t\tVerbose output\n"
    printf "  -d, --debug\t\tDebug output\n"
    printf "  --script\t\tDo not log results to a file\n"
  } >&2 # Redirects all output of this block to stderr
  exit 0
}
check_and_source_config() {
  while [ -n "$1" ]; do
    if [[ -f "$1" ]]; then
      # shellcheck disable=SC1090
      . "$1"
    else
      echo "ERROR: Could not find $1. Exiting."
      exit 1
    fi
    shift
  done
}
skip_if_processed() {
  # Uses fast grep to check if the SUID is already present in the output file
  if [ -f "$_LOG_MIGRATION" ]; then
    grep -qF "$1" "$_LOG_MIGRATION"
  else
    return 1
  fi
}
skip_if_present() {
  local suid=$1
  local numofobj
  numofobj=$(ssh -n 10.240.14.161 "sql.sh \"select numofimg from Dcstudy where styiuid='$suid'\" -N")
  if [ "$numofobj" -gt 5 ]; then
    return 0
  else
    return 1
  fi
}
interrupt_check() {
  # Check if the interrupt flag is set
  if [ "$interrupted" -eq 1 ]; then
    echo "Interrupted, exiting loop."
    return 1
  fi
}
getOptions() {
  executedByUser=True
  [ $# -eq 0 ] && DisplayUsage
  while [ -n "$1" ]; do
    case $1 in
      --help|-h)
        DisplayUsage
        ;;
      --verbose|-v)
        _VERBOSE_OPTS="--verbose"
        ;;
      --debug|-d)
        _DEBUG_OPTS="--debug"
        ;;
      --script)
        # shellcheck disable=SC2034
        executedByUser=False
        ;;
      --list|-L)
        if [ -n "$2" ] && [[ "$2" != -* ]]; then
          _INPUT_FILE="$2"
          shift
        else
          echo "Error: --list option requires a file argument."
          exit 1
        fi
        ;;
      --whatif|-if)
        _DRY_RUN="y"
        ;;
      *)
        printf "Unknown option (ignored): %s\n" "$1"
        DisplayUsage
        ;;
    esac
    shift
  done
}
custom_AET_Switcher() {
  local state_file="$(pwd)/aet_state"
  local current_aet

  # Check if the state file exists and read the current AET from it
  if [[ -f "$state_file" ]]; then
    read -r current_aet < "$state_file"
  else
    current_aet="eRAD0" # Initialize with a value not in the cycle to start with eRAD1
  fi

  # Cycle through the AET options
  case $current_aet in
    "eRAD1")
      _aet="eRAD2"
      ;;
    "eRAD2")
      _aet="eRAD3"
      ;;
    "eRAD3")
      _aet="eRAD4"
      ;;
    *)
      # This covers both the initialization case and the default case to loop back to eRAD1
      _aet="eRAD1"
      ;;
  esac

  # Save the new AET to the state file for the next call
  echo "$_aet" > "$state_file"

  # Optionally, echo the selected AET for verification
  # echo "Selected AET: $_aet"
  echo "$_aet"
}
main() {
  while read -r line; do
      interrupt_check || break
      if skip_if_processed "$line"; then
        printf "%s skipping %s, already processed\n" "$(date "+$_DATE_FMT")" "$line"
        continue
      fi
      if skip_if_present "$line"; then
        printf "%s skipping %s, already present\n" "$(date "+$_DATE_FMT")" "$line" | tee -a "$_LOG_MIGRATION"
        continue
      fi

      checkLoad
      interrupt_check || break

      _aet="$(custom_AET_Switcher)"

      # Transfer
      if [[ "$_DRY_RUN" == "y" ]]; then
        # shellcheck disable=SC2086
        ./transfer-dcm.sh $_DEBUG_OPTS $_VERBOSE_OPTS -S "$line" --calling-aet "$_aet" | tee -a "$_LOG_MIGRATION"
        # ./transfer-dcm.sh $_DEBUG_OPTS $_VERBOSE_OPTS -if -S "$line" | tee -a "$_LOG_MIGRATION"
        sleep 3
      else
        # shellcheck disable=SC2086
        ./transfer-dcm.sh $_DEBUG_OPTS $_VERBOSE_OPTS -S "$line" --calling-aet "$_aet" | tee -a "$_LOG_MIGRATION"
        # ./transfer-dcm.sh $_DEBUG_OPTS $_VERBOSE_OPTS -S "$line" | tee -a "$_LOG_MIGRATION"
        # ./transfer-dcm.sh $_DEBUG_OPTS $_VERBOSE_OPTS -S "$line" | head -1 | tee -a "$_LOG_MIGRATION"
        cat transfer-dcm.log
        _expected_img_count="$(parse_suboperations transfer-dcm.log)"
        wait_for_images "$_expected_img_count" "$line"
        sleep 0.5
      fi
      interrupt_check || break
  done < "$_INPUT_FILE"
}

_DATE_FMT="%Y%m%d-%H%M%S"
_INPUT_FILE=""
_DRY_RUN="n"
interrupted=0
trap 'interrupted=1' SIGINT

check_and_source_config "universal.lib" "universal.cfg" "transfer-dcm.cfg"
getOptions "$@"
main
trap - SIGINT # Reset trap to default behavior
